USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[UpdateEmployee]    Script Date: 26/05/2020 8:37:19 AM ******/
DROP PROCEDURE [dbo].[UpdateEmployee]
GO

/****** Object:  StoredProcedure [dbo].[UpdateEmployee]    Script Date: 26/05/2020 8:37:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[UpdateEmployee]
	-- Add the parameters for the stored procedure here
	@empid varchar(30),
 @firstname   varchar(50),
	  @middlename   varchar(50) ,
	 @lastname   varchar(50) ,
	
	 @gender   nchar ,
	 @dob date,
	 @dtehire date,
	 @status int,
	 @address varchar (150)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
Update Employees set firstname=@firstname,LastName=@lastname,MiddleName=@middlename,DateOfBirth=@dob,DateHired=@dtehire,Gender=@gender,EmpStatCode=@status,Address=@address
where EmployeeID=@empid
END
GO


