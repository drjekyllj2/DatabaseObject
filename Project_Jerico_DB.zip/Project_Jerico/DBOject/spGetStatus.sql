USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[GetStatus]    Script Date: 26/05/2020 8:36:40 AM ******/
DROP PROCEDURE [dbo].[GetStatus]
GO

/****** Object:  StoredProcedure [dbo].[GetStatus]    Script Date: 26/05/2020 8:36:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetStatus]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from Status 
END
GO


