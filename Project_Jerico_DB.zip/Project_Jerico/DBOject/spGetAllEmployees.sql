USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[GetAllEmployees]    Script Date: 26/05/2020 8:35:54 AM ******/
DROP PROCEDURE [dbo].[GetAllEmployees]
GO

/****** Object:  StoredProcedure [dbo].[GetAllEmployees]    Script Date: 26/05/2020 8:35:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GetAllEmployees] 
	@empID varchar(30)=''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


   if @empID=''
   begin
    -- Insert statements for procedure here
	SELECT EmployeeID,FirstName,MiddleName,LastName, format(DateHired,'yyyy-MM-dd')DateHired,s.EmpStatusDescription Status from Employees e, status s

	where e.EmpStatCode=s.EmpStatusCode
	end
  else 
    begin

	SELECT EmployeeID,FirstName,MiddleName,LastName,  DateHired,s.EmpStatusDescription Status,s.EmpStatusCode,DateOfBirth,Address,gender from Employees e, status s

	where e.EmpStatCode=s.EmpStatusCode
	and EmployeeID=@empID
	end

END
GO


