USE [CompanyData]
GO

/****** Object:  Table [dbo].[Employee]    Script Date: 26/05/2020 8:38:15 AM ******/
DROP TABLE [dbo].[Employee]
GO

/****** Object:  Table [dbo].[Employee]    Script Date: 26/05/2020 8:38:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Employee](
	[EmployeeID] [varchar](30) NULL,
	[EmployeeName] [varchar](70) NULL,
	[DateOfBirth] [date] NULL,
	[DateHired] [date] NULL,
	[DepartmentCode] [varchar](10) NULL
) ON [PRIMARY]
GO


