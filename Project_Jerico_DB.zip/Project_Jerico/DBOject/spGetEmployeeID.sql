USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[GetEmployeeID]    Script Date: 26/05/2020 8:36:20 AM ******/
DROP PROCEDURE [dbo].[GetEmployeeID]
GO

/****** Object:  StoredProcedure [dbo].[GetEmployeeID]    Script Date: 26/05/2020 8:36:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

 

CREATE PROCEDURE [dbo].[GetEmployeeID]

 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--declare @empid as int=0
 --   -- Insert statements for procedure here
	--SELECT  @empid =max(EmployeeID)    from Employees 
	-- print @empid
	--if isnull(@empid,'')=''
	-- set @empid=1
	--else
	-- set @empid = @empid+1
	   
	-- select @empid


	  declare @counter int
	 declare @Empid varchar(30)
	 declare @constant varchar(6)
	 declare @deptCode varchar(10)
	 declare @validate varchar(30)
	-- '2020-00001'

	 
	 select   @validate= employeeid from employees 

	 if isnull(@validate,'')=''
	 set @counter=0
	 else
	  select   @counter= MAx( cast (substring(employeeid,6,len(employeeid)-5  ) as int))from employees 

	 set @counter =  @counter + 1
	 set @constant= '-0000'
	 set @Empid=cast (YEAR(getdate()) as varchar(4)) + @constant + CAST(@counter as varchar(10))
 
     select  @Empid
	
	
END
GO


