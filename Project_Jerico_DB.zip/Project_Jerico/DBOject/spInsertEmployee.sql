USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[InsertEmployee]    Script Date: 26/05/2020 8:37:00 AM ******/
DROP PROCEDURE [dbo].[InsertEmployee]
GO

/****** Object:  StoredProcedure [dbo].[InsertEmployee]    Script Date: 26/05/2020 8:37:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InsertEmployee]
	 @Empname varchar(70),
	 @DateofBirth Date,
	 @HiredDate date,
	 @DepCode varchar(10)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 declare @counter int
	 declare @Empid varchar(30)
	 declare @constant varchar(6)
	 declare @deptCode varchar(10)
	 declare @validate varchar(30)
	-- '2020-00001'

	 
	 select   @validate= employeeid from employee 

	 if isnull(@validate,'')=''
	 set @counter=0
	 else
	  select   @counter= MAx( cast (substring(employeeid,6,len(employeeid)-5  ) as int))from employee 

	 set @counter =  @counter + 1
	 set @constant= '-0000'
	 set @Empid=cast (YEAR(getdate()) as varchar(4)) + @constant + CAST(@counter as varchar(10))
 
     select @deptCode = departmentcode from department where departmentcode =@DepCode

	 if isnull(@deptcode,'') =''
	 begin
	  select   'Department code ' + @depcode + ' does not exist' 
	  end
	 else
	  begin
	    insert into employee select @empid,@Empname,@DateofBirth,@HiredDate,@DepCode
	  end


	 
END
GO


