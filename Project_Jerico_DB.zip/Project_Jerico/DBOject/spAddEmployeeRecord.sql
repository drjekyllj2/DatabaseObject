USE [CompanyData]
GO

/****** Object:  StoredProcedure [dbo].[AddEmployeeRecord]    Script Date: 26/05/2020 8:34:28 AM ******/
DROP PROCEDURE [dbo].[AddEmployeeRecord]
GO

/****** Object:  StoredProcedure [dbo].[AddEmployeeRecord]    Script Date: 26/05/2020 8:34:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[AddEmployeeRecord] 
	-- Add the parameters for the stored procedure here
	 @EmpId   varchar(30),
	 @firstname   varchar(50),
	  @middlename   varchar(50) ,
	 @lastname   varchar(50) ,
	
	 @gender   nchar(1) ,
	 @dob date,
	 @dtehire date,
	 @status int,
	 @address varchar (150)
as
BEGIN
	-- SET NempidOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	insert into Employees select @empid,@firstname,@middlename,@lastname,@gender,@dob,@dtehire,@status,@address,GETDATE()

    -- Insert statements for procedure here
	 
END
GO


