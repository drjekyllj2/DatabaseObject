USE [CompanyData]
GO

/****** Object:  Table [dbo].[Status]    Script Date: 26/05/2020 8:39:07 AM ******/
DROP TABLE [dbo].[Status]
GO

/****** Object:  Table [dbo].[Status]    Script Date: 26/05/2020 8:39:07 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Status](
	[EmpStatusCode] [int] IDENTITY(1,1) NOT NULL,
	[EmpStatusDescription] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED 
(
	[EmpStatusCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


