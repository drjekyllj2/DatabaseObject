insert into department select 'CLSD', 'Corporate and Loans Systems Department'
insert into department select 'SMSD', 'Service Management Support Department'
insert into department select 'RASD','Remittance and Auxiliary Systems'
insert into department select 'ECRD', 'E-Channel Retail Department'



insert into employee select '2020-00001','Juan Dela Cruz 1','1/25/1980', '1/28/2010','CLSD'
insert into employee select '2020-00002','Juan Dela Cruz 2','2/15/1994', '2/5/2020','SMSD'
insert into employee select '2020-00003','Juan Dela Cruz 3','6/8/1992', '3/5/2020','CLSD'
insert into employee select '2020-00004','Juan Dela Cruz 4','3/25/1988', '12/5/2019','SMSD'
insert into employee select '2020-00005','Juan Dela Cruz 5','4/5/1984', '10/8/2009','RASD'
insert into employee select '2020-00006','Juan Dela Cruz 6','3/25/1985', '11/25/2019','RASD'
insert into employee select '2020-00007','Juan Dela Cruz 7','10/17/1980', '11/19/2018','ECRD'
insert into employee select '2020-00008','Juan Dela Cruz 8','12/8/1970', '5/5/2000','ECRD'
insert into employee select '2020-00009','Juan Dela Cruz 9','2/20/1990', '5/2/2016','ECRD'
insert into employee select '2020-000010','Juan Dela Cruz 10','11/5/1982', '5/1/2016','ECRD'

select * from viewemployee
